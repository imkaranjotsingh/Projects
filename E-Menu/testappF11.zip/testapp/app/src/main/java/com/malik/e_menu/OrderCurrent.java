package com.malik.e_menu;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public  class OrderCurrent {
    static   HashMap<String,String> stringListHashMap =new HashMap<String,String>();
    public void costcounter(){
        int cost=0;
        int i = 0;
        Iterator<Map.Entry<String, String>> it = stringListHashMap.entrySet().iterator();
       while (it.hasNext()&&i<=CheckOut.price123.size()){
           Map.Entry pair = it.next();
           int p1= Integer.parseInt((String) pair.getValue());
           int p2=CheckOut.price123.get(i);
            cost+=p1*p2;
            i++;
       }
        CheckOut.totalcost=cost;
    }
}
