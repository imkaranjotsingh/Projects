package com.malik.e_menu;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.malik.e_menu.CheckOut.listView_co;

public class CheckoutAdapter extends BaseAdapter {
    ArrayList<String> name;
    static ArrayList<Integer> price;
    ArrayList<Integer> ids;
    ImageButton inc;
    ImageButton dec;
    ImageButton remove;
    ArrayList<EditText> Ed;
    Context context;
    ListView listView;

    public CheckoutAdapter(ArrayList<Integer> ids, ArrayList<String> name, ArrayList<Integer> price, ArrayList<EditText> Ed, Context context) {
        this.name = name;
        CheckoutAdapter.price = price;
        this.Ed = Ed;
        this.ids = ids;
        this.context = context;
    }

    @Override
    public int getCount() {
        return name.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View v, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.design_co, null);
        TextView textView = v.findViewById(R.id.co_name);
        textView.setText(name.get(position));
        TextView textView2 = v.findViewById(R.id.co_price);
        textView2.setText("₹" + price.get(position).toString());
        final EditText txtCount = v.findViewById(R.id.item_qty);
        txtCount.setText("1");
        final int[] count = {1};
        txtCount.setText(String.valueOf(count[0]));
        inc = v.findViewById(R.id.increase);
        inc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count[0] == 50) {
                    Toast.makeText(context, "Error : Quantity Cannot be More Than 50", Toast.LENGTH_SHORT).show();
                } else {
                    count[0]++;
                    txtCount.setText(String.valueOf(count[0]));
                    OrderCurrent.stringListHashMap.put(String.valueOf(AdapterClass.idss.get(position)),String.valueOf(count[0]));
               }
            }
        });
        dec = v.findViewById(R.id.decrease);
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count[0] == 1) {
                    Toast.makeText(context, "Error : Quantity Cannot be 0", Toast.LENGTH_SHORT).show();
                } else {
                    count[0]--;
                    txtCount.setText(String.valueOf(count[0]));
                    OrderCurrent.stringListHashMap.put(String.valueOf(AdapterClass.idss.get(position)),String.valueOf(count[0]));
                }
            }
        });
        remove = v.findViewById(R.id.bin);
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
                try {
                    int idx = 0;
                    while (idx < AdapterClass.idss.size()) {
                        if (String.valueOf(AdapterClass.idss.get(idx)).equals(String.valueOf(ids.get(position)))) {
                            AdapterClass.idss.remove(idx);
                                OrderCurrent.stringListHashMap.remove(String.valueOf(AdapterClass.idss.get(position)));
                                notifyDataSetChanged();
                                break;
                        } else {
                            ++idx;
                        }
                    }
                    notifyDataSetChanged();
                } catch (Exception e) {
                    System.out.println(e.getMessage().toUpperCase());
                }
            }
        });

        return v;
    }
}
