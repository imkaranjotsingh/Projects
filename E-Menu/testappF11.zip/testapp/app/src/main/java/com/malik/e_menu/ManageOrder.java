package com.malik.e_menu;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ManageOrder extends AppCompatActivity {
    ListView listView;
    Context context;
    private boolean active;

    public ManageOrder(){
    }
    class innerAdapter extends BaseAdapter {
        ArrayList<Integer> table_No;
        ArrayList<String>  timeStamp;
        ArrayList<Integer> orderid;
        ArrayList<String> order;
        ImageButton vieworder;
        ImageButton donebtn;
        Context context;
        public  innerAdapter(ArrayList<Integer> table_No, ArrayList<String> timeStamp, ArrayList<String> order, ArrayList<Integer> orderid, Context context){
            this.table_No=table_No;
            this.order=order;
            this.orderid=orderid;
            this.timeStamp=timeStamp;
            this.context=context;
        }
        @Override
        public int getCount() {
            return table_No.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View v, ViewGroup parent) {
            LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.design_om, null);
            TextView textView = v.findViewById(R.id.co_table);
            textView.append(table_No.get(position).toString());
            TextView textView2 = v.findViewById(R.id.co_TimeStamp);
            textView2.append(timeStamp.get(position));
            vieworder= v.findViewById(R.id.order_view);
            donebtn= v.findViewById(R.id.order_done);
            vieworder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(context,CompleteOrderList.class);
                    intent.putExtra("TableNo",table_No.get(position).toString());
                    intent.putExtra("OrderString",order.get(position));
                    context.startActivity(intent);
                }
            });
            donebtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ManageOrder.this);
                    builder.setCancelable(true);
                    builder.setTitle("Confirmation");
                    builder.setMessage("Are You Sure This Order in Done");
                    builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    new DeleteItem_JSON(orderid.get(position).toString(),"order",getApplicationContext()).execute();
                                    if(orderid.isEmpty()){
                                        listView.setBackgroundResource(R.mipmap.noorder);
                                    }
                                    runtask();
                                }
                            });
                    builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            runtask();
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                    runtask();
                }
            });
            return v;
        }
    }
    class myAsynTask extends AsyncTask<Object,Object,Object> {
        ArrayList<String> order = new ArrayList<>();
        ArrayList<Integer> tableno = new ArrayList<>();
        ArrayList<String> timestamp = new ArrayList<>();
        ArrayList<Integer> totalamountt = new ArrayList<>();
        ArrayList<Integer> orderid=new ArrayList<>();
        ListView listView;
        Context context;

        myAsynTask(Context context, ListView listView) {
            this.context = context;
            this.listView = listView;
        }

        @Override
        protected Object doInBackground(Object... objects) {

            String url = "http://" + UserSelection.urlget + "/resturent_servicetest.php?act=Get_Order_List";
            Log.i("urls", url);
            ServiceHandler handler = new ServiceHandler(url);
            String response = handler.makeServicecall();

            try {
                // JSONObject jsonObject=new JSONObject(response);
                JSONArray status = new JSONArray(response);
                for (int i = 0; i < status.length(); i++) {
                    JSONObject json = status.getJSONObject(i);
                    tableno.add(json.getInt("tableNumber"));
                    order.add(json.getString("orderDetails"));
                    totalamountt.add(json.getInt("orderAmount"));
                    timestamp.add(json.getString("orderTime"));
                    orderid.add(json.getInt("orderid"));
                    System.out.println(timestamp + "       " + order);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(orderid.isEmpty()){
                listView.setBackgroundResource(R.mipmap.noorder);
            }
           innerAdapter adapter = new innerAdapter(tableno, timestamp, order,orderid, context);
            listView.setAdapter(adapter);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_manage_order);
        listView= findViewById(R.id.mng_order_list);
       runtask();
    }
    public void runtask() {
        new myAsynTask(getApplicationContext(), listView).execute();
    }
}
