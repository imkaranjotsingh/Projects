package com.malik.e_menu;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;


public class OldplaceOrderJSON extends AsyncTask<Object,Object,Object> {

    String tn;
    String order;
    int price;
    String status;
    Context context;
    String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
    public OldplaceOrderJSON(String tn, String order, int price, Context context) {
        this.order = order.replaceAll(" ","%20");
        this.tn = tn;
        this.price = price;
        this.context  = context;
        String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date()).replaceAll(" ","%20");
        this.currentDateTimeString = currentDateTimeString.replaceAll(",","");
        order = order.replaceAll("[{]","%7B");
        order = order.replaceAll("[}]","%7D");
        order = order.replaceAll("=","%3D");
        this.order = order.replaceAll(",","%2C").replaceAll(" ","%20");
    }

    @Override
    protected Object doInBackground(Object... objects) {
        /*CheckOut oc = new CheckOut();
        oc.costcounter();*/
        String url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=Send_Order&Request_tableNumber="+ tn +"&Request_orderDetails="+order+"&Request_orderAmount="+String.valueOf(CheckOut.totalcost)+"&Request_orderTime="+currentDateTimeString;
        Log.i("urls",url);
        ServiceHandler handler = new ServiceHandler(url);
        String response = handler.makeServicecall();
        try {
            JSONObject jsonObject=new JSONObject(response);
            status = jsonObject.getString("AccountCreated");
            if(status.equals("DatasubmittedSuccessfully")){

            }
            else
                {

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }


    @Override
    protected void onPostExecute(Object o) {
    }
}
