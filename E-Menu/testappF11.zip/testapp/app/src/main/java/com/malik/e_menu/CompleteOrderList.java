package com.malik.e_menu;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class CompleteOrderList extends AppCompatActivity {
    ListView cmplt_order;
    String tableno;
    String str;
    ArrayList<String> orders;
    ArrayList<String> orderqty;
    Context context;

    public CompleteOrderList() {
    }

    class myAsynTask extends AsyncTask<Object, Object, Object> {

        Context context;
        ListView listView;
        ArrayList<Integer> getidd=new ArrayList<Integer>();
        ArrayList<String> getname=new ArrayList<String>();
        ArrayList<String> getcuisine=new ArrayList<String>();
        ArrayList<String> gettype=new ArrayList<String>();
        myAsynTask(Context context, ListView listView) {
            this.context = context;
            this.listView = listView;
        }
        @Override
        protected Object doInBackground(Object[] objects) {
            String urlsp = new sharedprefclass().getpref(context);
            for (int i = 0; i <orders.size();i++) {
                String url = "http://" + urlsp + "/resturent_servicetest.php?act=Search_Items&Request_id="+ orders.get(i);
                Log.i("urls", url);
                ServiceHandler handler = new ServiceHandler(url);
                String response = handler.makeServicecall();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    getidd.add(jsonObject.getInt("id"));
                    getname.add(jsonObject.getString("name"));
                    getcuisine.add(jsonObject.getString("cuisine"));
                    gettype.add(jsonObject.getString("type"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            CompleteOLAdapter adapter=new CompleteOLAdapter(tableno,getname,getcuisine,gettype,orderqty,getApplicationContext());
            cmplt_order.setAdapter(adapter);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_order_list);
        Properties props = new Properties();
        tableno= getIntent().getStringExtra("TableNo");
        str = getIntent().getStringExtra("OrderString");
        try {
            props.load(new StringReader(str.substring(1, str.length() - 1).replace(", ", "\n")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Map<String, String> map2 = new HashMap<String, String>();
        for (Map.Entry<Object, Object> e : props.entrySet()) {
            map2.put((String) e.getKey(), (String) e.getValue());
        }
        Log.i("MAP TEST", map2.toString());
        orders = new ArrayList<>(map2.keySet());
        orderqty = new ArrayList<>(map2.values());
        cmplt_order = findViewById(R.id.cmplt_order);
        TextView textView = findViewById(R.id.textView5);
        textView.setText("Order of Table No. : " + tableno);
        runtask(cmplt_order);
    }
    public void  runtask(ListView lv){
        new myAsynTask(getApplicationContext(),lv).execute();
    }
}
