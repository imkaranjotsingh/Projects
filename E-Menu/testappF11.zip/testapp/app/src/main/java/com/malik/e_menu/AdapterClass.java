package com.malik.e_menu;

import android.content.Context;
import android.graphics.ImageFormat;
import android.opengl.Visibility;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class AdapterClass extends BaseAdapter {

    ArrayList<String> name;
    static  ArrayList<String> idss =new ArrayList<String>();
    ArrayList<String> price;
    ArrayList<Integer> ids;
    ArrayList<EditText> Ed;
    ImageButton addtocart;

    int item = 0;
//    ArrayList<Button> btn;
    Context context;

    public AdapterClass(ArrayList<String> name, ArrayList<String> price,ArrayList<Integer> ids, Context context) {
        this.name = name;
        this.price = price;
        this.ids = ids;
        this.context = context;
    }

    @Override
    public int getCount() {
        return price.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View v, ViewGroup parent) {


        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.design,null);

        TextView n = v.findViewById(R.id.name);
        n.setText(name.get(position));

        TextView p = v.findViewById(R.id.price);
        p.setText(price.get(position));
        HashMap<ArrayList<String>,Boolean> random = new HashMap<ArrayList<String>,Boolean>();
        addtocart= v.findViewById(R.id.insert_itm_btn);
        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("ItemAddButtonResponse" , "Alreafty");
                if(idss.contains(String.valueOf(ids.get(position)))){
                    Log.i("ItemAddButtonResponse" , "Button Clicked!");
                    Toast.makeText(context, "Already in Cart!", Toast.LENGTH_SHORT).show();
                }else {
                    Log.i("ItemAddButtonResponse" , "Added");
                    idss.add(String.valueOf(ids.get(position)));
                    OrderCurrent.stringListHashMap.put(String.valueOf(ids.get(position)),"1");
                    Toast.makeText(context, "Added to Cart!", Toast.LENGTH_SHORT).show();

                }
            }
        });

        return v;
    }
}
