package com.malik.e_menu;

import android.content.Context;
import android.content.SharedPreferences;

public class sharedprefclass{
SharedPreferences preferences;
Boolean user;
    public void setpref(Context context,String string){
        preferences =context.getSharedPreferences("User",Context.MODE_PRIVATE);
        preferences.edit().putString("userIp",string);
       // return user;
}

    public String getpref(Context context){
        preferences= context.getSharedPreferences("User",Context.MODE_PRIVATE);
        String ip = preferences.getString("userIp",null);
        return ip;
    }

}