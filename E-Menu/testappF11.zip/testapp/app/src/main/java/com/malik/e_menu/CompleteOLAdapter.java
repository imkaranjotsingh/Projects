package com.malik.e_menu;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class CompleteOLAdapter extends BaseAdapter {
    String table_No;
    ArrayList<String> qty = new ArrayList<String>();
    ArrayList<String> Name= new ArrayList<String>();
    ArrayList<String> Cuisine= new ArrayList<String>();
    ArrayList<String> type= new ArrayList<String>();
    Context context;

    public CompleteOLAdapter(String table_No, ArrayList<String> Name, ArrayList<String> Cuisine, ArrayList<String> type, ArrayList<String> qty, Context context) {
        this.type = type;
        this.qty = qty;
        this.Cuisine = Cuisine;
        this.Name = Name;
        this.context = context;
        this.table_No = table_No;
    }

    @Override
    public int getCount() {
        return Name.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View v, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.design_col, null);
        TextView textView = v.findViewById(R.id.col_name);
        textView.setText(Name.get(position));
        TextView textView2 = v.findViewById(R.id.col_cuisine);
        textView2.setText(Cuisine.get(position));
        TextView textView1 = v.findViewById(R.id.col_qts);
        textView1.setText(qty.get(position));
        Log.i("TAG111111111111111111111111111111", qty.get(position) + Name.get(position));
        textView1.setText(qty.get(position));
        return v;
    }
}
