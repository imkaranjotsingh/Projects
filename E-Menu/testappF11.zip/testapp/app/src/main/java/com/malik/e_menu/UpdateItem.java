package com.malik.e_menu;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class UpdateItem extends AppCompatActivity {
    EditText id, name, price;
    String[] types = {"Veg", "Non-Veg"};
    String[] cuisines = {"Chinese", "Italian", "Continental", "NorthIndian", "Mughlai", "SouthIndian"};
    String[] Categories = {"Starters", "Beverages", "MainCourse", "Desert", "Rice&Bread"};
    Spinner type, cuisine, category;
    Button update;
    Boolean searchtask =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);
        type = findViewById(R.id.type);
        cuisine = findViewById(R.id.cuisine);
        category = findViewById(R.id.category);
        id = findViewById(R.id.search_id);
        name = findViewById(R.id.item_name);
        price = findViewById(R.id.item_price);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, types);
        type.setAdapter(adapter);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, cuisines);
        cuisine.setAdapter(adapter1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, Categories);
        category.setAdapter(adapter2);
        update = findViewById(R.id.update_btn);
        type.setVisibility(View.INVISIBLE);
        name.setVisibility(View.INVISIBLE);
        category.setVisibility(View.INVISIBLE);
        cuisine.setVisibility(View.INVISIBLE);
        update.setVisibility(View.INVISIBLE);
        price.setVisibility(View.INVISIBLE);
        Button search=(Button) findViewById(R.id.search_btn3);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new searchTask(id.getText().toString(),getApplicationContext()).execute();
                if (searchtask){
                type.setVisibility(View.VISIBLE);
                name.setVisibility(View.VISIBLE);
                category.setVisibility(View.VISIBLE);
                cuisine.setVisibility(View.VISIBLE);
                update.setVisibility(View.VISIBLE);
                price.setVisibility(View.VISIBLE);
                }
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(UpdateItem.this, "Clicked", Toast.LENGTH_SHORT).show();
                new myAsyncTask(id.getText().toString(), name.getText().toString(),
                        cuisine.getSelectedItem().toString(), category.getSelectedItem().toString(),
                        type.getSelectedItem().toString(), price.getText().toString(), UpdateItem.this).execute();
            }
        });

    }

    public class myAsyncTask extends AsyncTask<Object,Object,Object>
    {
        String id,name,cuisine,category,type,price,urlsp;
        String status;
        Context context;
        public myAsyncTask(String id, String name, String cuisine, String category, String type, String price, Context context) {
            this.name = name;
            this.id = id;
            this.cuisine = cuisine;
            this.category = category;
            this.type = type;
            this.price = price;
            this.context  = context;
        }
        @Override
        protected Object doInBackground(Object... objects) {
            name=name.replaceAll(" ","%20");
            category= category.replaceAll(" ","%20");
            type=type.replaceAll(" ","%20");
            cuisine=cuisine.replaceAll(" ","%20");
            String url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=Update_Item&Request_id="+id+"&Request_name="+name+"&Request_cuisine="+cuisine+"&Request_category="+category+"&Request_type="+type+"&Request_price="+price;
            Log.i("urls",url);
            ServiceHandler handler = new ServiceHandler(url);
            String response = handler.makeServicecall();
            try {
                JSONObject jsonObject=new JSONObject(response);
                status = jsonObject.getString("result");
                } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(status.equals("success")){
                Toast.makeText(getApplicationContext(), "Item Updated Successfully !", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getApplicationContext(), "Item Not Updated !", Toast.LENGTH_SHORT).show();
            }


        }
    }
    public class searchTask extends AsyncTask<Object,Object,Object>{

        String id,urlsp;
        String status;
        Context context;
        public searchTask(String id, Context context) {
            this.id = id;
            this.context  = context;
        }

        @Override
        protected Object doInBackground(Object... objects) {
            urlsp=new sharedprefclass().getpref(context);
            String url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=Search_Items&Request_id="+id;
            Log.i("urls",url);
            ServiceHandler handler = new ServiceHandler(url);
            String response = handler.makeServicecall();
            try {
                JSONObject jsonObject=new JSONObject(response);
                status = jsonObject.getString("isFound");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(status.equalsIgnoreCase("YES")){
                searchtask=true;
                Toast.makeText(getApplicationContext(), "Item Found Please Update", Toast.LENGTH_SHORT).show();
                }
                else{
                searchtask=false;
                Toast.makeText(getApplicationContext(), "No Item Found", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
