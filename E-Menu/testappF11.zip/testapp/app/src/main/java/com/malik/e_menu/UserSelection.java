package com.malik.e_menu;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.usb.UsbRequest;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class UserSelection extends AppCompatActivity {
    Button admin,user,geturlfromuser;
    EditText urlfromuser;
    String urlsp;
    Boolean isConnected=false;
    public static String urlget="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selection);
        admin= findViewById(R.id.admin_btn);
        urlfromuser= findViewById(R.id.getUrl);
        geturlfromuser= findViewById(R.id.button4);
        urlfromuser.setText(new sharedprefclass().getpref(getApplicationContext()));
        geturlfromuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String urlmain=urlfromuser.getText().toString();
                if(!urlmain.isEmpty()){
                Log.i("ENTERED : ", urlmain);
                urlget=urlmain;
                new sharedprefclass().setpref(getApplicationContext(),urlget);
                Toast.makeText(UserSelection.this, urlget, Toast.LENGTH_SHORT).show();
                new myAsynTask(getApplicationContext()).execute();}
                else
                    Toast.makeText(UserSelection.this, "Enter Server URL", Toast.LENGTH_SHORT).show();
            }
        });
        user= findViewById(R.id.user_btn);
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkurl())
                    Toast.makeText(UserSelection.this, "URL cannot be empty", Toast.LENGTH_SHORT).show();
                else
                startActivity(new Intent(UserSelection.this,LoginPage.class));

            }
        });
        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkurl())
                    Toast.makeText(UserSelection.this, "URL cannot be empty", Toast.LENGTH_SHORT).show();
                else
                startActivity(new Intent(UserSelection.this,UserHome.class));

            }
        });
    }
    public Boolean checkurl(){
        return urlget.isEmpty();
    }

    public void setVisibility()    {
        if (isConnected) {
            geturlfromuser.setVisibility(View.INVISIBLE);
            urlfromuser.setVisibility(View.INVISIBLE);
        }
        else if (!isConnected){
            geturlfromuser.setVisibility(View.VISIBLE);
            urlfromuser.setVisibility(View.VISIBLE);
        }
    }

    class myAsynTask extends AsyncTask<Object,Object,Object>{
        String status;
        Context context;
        myAsynTask(Context context){
            this.context = context;
        }
        @Override
        protected Object doInBackground(Object... objects) {
            String url;
            url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=checkConnection";
            Log.i("urls",url);
            ServiceHandler handler = new ServiceHandler(url);
            String response = handler.makeServicecall();
            try {
                JSONObject jsonObject=new JSONObject(response);
                status = jsonObject.getString("result");


            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            if(status.equalsIgnoreCase("connected")){
                isConnected=true;
                Toast.makeText(UserSelection.this, "Server Connected Successfully", Toast.LENGTH_SHORT).show();
                setVisibility();
            }
            else if(status.equalsIgnoreCase("failed")) {
                isConnected=false;
                Toast.makeText(UserSelection.this, "Server Connection Failed", Toast.LENGTH_SHORT).show();
                setVisibility();
            }
        }
    }
}
