package com.malik.e_menu;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.StringReader;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class CheckOut extends AppCompatActivity {
    static ListView listView_co;
    TextView textViewtotal;
    Context context;
    static ArrayList<Integer> price123;
    static int totalcost=0;
    Button place_order;
    public CheckOut() {
    }
    class innerAdapter extends BaseAdapter{
        ArrayList<String> name;
        ArrayList<Integer> price;
        ArrayList<Integer> ids;
        ImageButton inc;
        ImageButton dec;
        ImageButton remove;
        ArrayList<EditText> Ed;
        Context context;
        ListView listView;
        public ArrayList<Integer> returnprice(){
            return price;
        }

        public innerAdapter(ArrayList<Integer> ids, ArrayList<String> name, ArrayList<Integer> price, ArrayList<EditText> Ed, Context context) {
            this.name = name;
            this.price = price;
            this.Ed = Ed;
            this.ids = ids;
            this.context = context;
            price123=this.price;
                    }
        @Override
        public int getCount() {
            return name.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View v, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.design_co, null);
            final TextView textView = v.findViewById(R.id.co_name);
            textView.setText(name.get(position));
            textViewtotal = findViewById(R.id.Total);
            TextView textView2 = v.findViewById(R.id.co_price);
            textView2.setText("₹" + price.get(position).toString());
            costcounter1();
            textViewtotal.setText("Total : ₹" + String.valueOf(totalcost));
            final EditText txtCount = v.findViewById(R.id.item_qty);
            final int[] count = {1};
            txtCount.setText(String.valueOf(count[0]));
            inc = v.findViewById(R.id.increase);
            inc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (count[0] == 50) {
                        Toast.makeText(context, "Error : Quantity Cannot be More Than 50", Toast.LENGTH_SHORT).show();
                    } else {
                        count[0]++;
                        OrderCurrent.stringListHashMap.put(String.valueOf(AdapterClass.idss.get(position)),String.valueOf(count[0]));
                        txtCount.setText(OrderCurrent.stringListHashMap.get(AdapterClass.idss.get(position)));

                        costcounter1();
                        textViewtotal.setText("Total : ₹" + String.valueOf(totalcost));
                    }
                }
            });
            dec = v.findViewById(R.id.decrease);
            dec.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (count[0] == 1) {
                        Toast.makeText(context, "Error : Quantity Cannot be 0", Toast.LENGTH_SHORT).show();
                    } else {
                        count[0]--;
                        OrderCurrent.stringListHashMap.put(String.valueOf(AdapterClass.idss.get(position)),String.valueOf(count[0]));
                        txtCount.setText(OrderCurrent.stringListHashMap.get(AdapterClass.idss.get(position)));

                        txtCount.setText(OrderCurrent.stringListHashMap.get(AdapterClass.idss.get(position)));
                        costcounter1();
                        textViewtotal.setText("Total : ₹"+String.valueOf(totalcost));
                    }
                }
            });
            remove = v.findViewById(R.id.bin);
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v1) {
                        int idx = 0;
                        while (idx < AdapterClass.idss.size()) {
                            if (String.valueOf(AdapterClass.idss.get(idx)).equals(String.valueOf(ids.get(position)))) {
                                AdapterClass.idss.remove(idx);
                                OrderCurrent.stringListHashMap.remove(ids.get(position).toString());
                                run();
                                if (AdapterClass.idss.isEmpty())
                                {
                                    startActivity(getIntent());
                                }
                                break;
                            } else {
                                ++idx;
                            }
                        }
                        notifyDataSetChanged();

                }
            });

            return v;
        }
        public void costcounter1(){
            int cost=0;
            int i = 0;

            Iterator<Map.Entry<String, String>> it = OrderCurrent.stringListHashMap.entrySet().iterator();
            while (it.hasNext()&&i<=this.price.size()){
                Map.Entry pair = it.next();
                int p1= Integer.parseInt((String) pair.getValue());
                int p2=Integer.parseInt(String.valueOf(this.price.get(i)));
                cost+=p1*p2;
                i++;
                CheckOut.totalcost=cost;

            }
        }
    }
    class myAsynTask extends AsyncTask<Object, Object, Object> {

        ArrayList<String> name = new ArrayList<>();
        ArrayList<Integer> price = new ArrayList<>();
        ArrayList<EditText> Ed = new ArrayList<>();
        ArrayList<Integer> id = new ArrayList<>();
        String getId, getname, getprice;
        Integer getidd, price1;
        String status;
        Context context2;
        ListView listView2;

        myAsynTask(Context context2, ListView listView2) {
            this.context2 = context2;
            this.listView2 = listView2;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Object doInBackground(Object... objects) {
            if (AdapterClass.idss.isEmpty()) {
                listView_co.setBackgroundResource(R.drawable.emptyart);
            }
            for (int i = 0; i < AdapterClass.idss.size(); i++) {
                String itemidds = AdapterClass.idss.get(i);
                itemidds.replaceAll(" ", "%20");
                String url = "http://" + UserSelection.urlget + "/resturent_servicetest.php?act=Search_Items&Request_id=" + itemidds;
                Log.i("urls", url);
                ServiceHandler handler = new ServiceHandler(url);
                String response = handler.makeServicecall();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Boolean resultsent = jsonObject.optBoolean("resultsent");
                    getidd = jsonObject.getInt("id");
                    status = jsonObject.getString("isFound");
                    getname = jsonObject.getString("name");
                    price1 = jsonObject.getInt("price");
                    Log.i("tes>>>>>>>>>>>>>>t", getname);
                    name.add(getname);
                    price.add(price1);
                    id.add(getidd);
                    getprice = price.toString();
                    getId = getidd.toString();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            innerAdapter adapter = new innerAdapter(id, name, price, Ed, context2);
            listView_co.setAdapter(adapter);
        }
    }
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_check_out);
            listView_co = findViewById(R.id.co_list);
            place_order = findViewById(R.id.plc_order);
            place_order.setVisibility(View.VISIBLE);
            ConstraintLayout constraintLayout = findViewById(R.id.checkoutlayout);
            final String[] m_Text = new String[1];
            if (AdapterClass.idss.isEmpty()) {
                OrderCurrent.stringListHashMap.clear();
                place_order.setVisibility(View.INVISIBLE);
                listView_co.setBackgroundResource(R.drawable.emptyart);
                constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFF"));

            }
            listView_co.removeAllViewsInLayout();
            run();
            place_order.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // create map
                    if (!AdapterClass.idss.isEmpty()) {
                        final String str = OrderCurrent.stringListHashMap.toString();
                        AlertDialog.Builder builder = new AlertDialog.Builder(CheckOut.this);
                        builder.setTitle("Please, Enter Table No.");
                        final EditText input = new EditText(CheckOut.this);
                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                        builder.setView(input);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try{
                                m_Text[0] = input.getText().toString();
                                String text = m_Text[0];
                                new placeOrderJSON(text, str, totalcost, context).execute();
                                AdapterClass.idss.clear();
                                OrderCurrent.stringListHashMap.clear();
                                if (AdapterClass.idss.isEmpty()) {
                                    listView_co.setBackgroundResource(R.drawable.emptyart);
                                    place_order.setVisibility(View.INVISIBLE);
                                }
                            }
                            catch (Exception e)
                            {
                                Log.i("Error Checkout",e.toString());
                            }
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                        builder.show();
                    }
                    else {
                        Toast.makeText(CheckOut.this, "Cart cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        public void run() {
            new myAsynTask(getApplicationContext(), listView_co).execute();
        }

        public void costcounter() {
            int cost = 0;
            int i = 0;

            Iterator<Map.Entry<String, String>> it = OrderCurrent.stringListHashMap.entrySet().iterator();
            while (it.hasNext() && i <= price123.size()) {
                Map.Entry pair = it.next();
                int p1 = Integer.parseInt((String) pair.getValue());
                int p2 = price123.get(i);
                cost += p1 * p2;
                i++;
                CheckOut.totalcost = cost;

            }
        }
        
        public class placeOrderJSON extends AsyncTask<Object,Object,Object>{


            String tn;
            String order;
            int price;
            String status,urlsp;
            Context context;
            String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
            public placeOrderJSON(String tn, String order, int price, Context context) {
                this.order = order.replaceAll(" ","%20");
                this.tn = tn;
                this.price = price;
                this.context  = context;
                String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date()).replaceAll(" ","%20");
                this.currentDateTimeString = currentDateTimeString.replaceAll(",","");
                order = order.replaceAll("[{]","%7B");
                order = order.replaceAll("[}]","%7D");
                order = order.replaceAll("=","%3D");
                this.order = order.replaceAll(",","%2C").replaceAll(" ","%20");
            }

            @Override
            protected Object doInBackground(Object... objects) {
        /*CheckOut oc = new CheckOut();
        oc.costcounter();*/
                String url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=Send_Order&Request_tableNumber="+ tn +"&Request_orderDetails="+order+"&Request_orderAmount="+String.valueOf(CheckOut.totalcost)+"&Request_orderTime="+currentDateTimeString;
                Log.i("urls",url);
                ServiceHandler handler = new ServiceHandler(url);
                String response = handler.makeServicecall();
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    status = jsonObject.getString("AccountCreated");


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return null;
            }


            @Override
            protected void onPostExecute(Object o) {
                if(status.equals("DatasubmittedSuccessfully")){
                    Toast.makeText(CheckOut.this, "Order Placed Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), UserHome.class));

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Error !", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), UserHome.class));
                }
            }
        }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(),MenuTab.class));
    }
   }
