package com.malik.e_menu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OrderedItemList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordered_item_list);
    }
}
