package com.malik.e_menu;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import com.malik.e_menu.ServiceHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class search_JSON extends AsyncTask<Object,Object,Object> {
    String[] itemdetails=null;
    String id;
    String status;
    Context context;
    String getId,getname,getcuisine,getcategory,gettype,getprice,urlsp;
    Integer getidd,price;
    TextView textView;
    public search_JSON(String id,Context context,TextView textView) {
        this.id = id;
        this.context  = context;
        this.textView=textView;
    }



    @Override
    protected Object doInBackground(Object... objects) {
        String url = "http://"+UserSelection.urlget+"/resturent_servicetest.php?act=Search_Items&Request_id="+id;
        Log.i("urls",url);
        ServiceHandler handler = new ServiceHandler(url);
        String response = handler.makeServicecall();

        try {
           JSONObject jsonObject=new JSONObject(response);
            getidd=jsonObject.getInt("id");
            getname=jsonObject.getString("name");
            getcuisine=jsonObject.getString("cuisine");
            getcategory=jsonObject.getString("category");
            gettype=jsonObject.getString("type");
            price=jsonObject.getInt("price");
                Log.i("tes>>>>>>>>>>>>>>t",getname+" "+getcategory+" "+getcuisine);
                getprice=price.toString();
                getId=getidd.toString();
                itemdetails=new String[]{getId, getname, getcuisine, getcategory, gettype, getprice};
                System.out.println(itemdetails[0] + itemdetails[1]);
                String settexrstr=textView.getText().toString()+"ID : "+ itemdetails[0] +"\n"+"Name : "+ itemdetails[1] +"\n"+
                        "Cuisine : "+ itemdetails[2] +"\n"+"Category : "+ itemdetails[3] +"\n"
                        +"Type : "+ itemdetails[4] +"\n"+"Price : " + itemdetails[5];
                textView.setText(settexrstr);
                   } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            String settexrstr="ID : "+ itemdetails[0] +"\n"+"Name : "+ itemdetails[1] +"\n"+
                    "Cuisine : "+ itemdetails[2] +"\n"+"Category : "+ itemdetails[3] +"\n"
                    +"Type : "+ itemdetails[4] +"\n"+"Price : " + itemdetails[5];
            textView.setText(settexrstr);
        }catch (Exception e){
            System.out.print(e.getMessage().toUpperCase());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
    }
}
