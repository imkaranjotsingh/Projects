package com.malik.e_menu;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class ManageOrderAdapter extends BaseAdapter {
    ArrayList<Integer> table_No;
    ArrayList<String>  timeStamp;
    ArrayList<String> order;
    ImageButton vieworder;
    ImageButton donebtn;
    Context context;
    public  ManageOrderAdapter(ArrayList<Integer> table_No, ArrayList<String> timeStamp, ArrayList<String> order, Context context){
        this.table_No=table_No;
        this.order=order;
        this.timeStamp=timeStamp;
        this.context=context;
    }
    @Override
    public int getCount() {
        return table_No.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View v, ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.design_om, null);
        TextView textView = v.findViewById(R.id.co_table);
        textView.append(table_No.get(position).toString());
        TextView textView2 = v.findViewById(R.id.co_TimeStamp);
        textView2.append(timeStamp.get(position));
        vieworder= v.findViewById(R.id.order_view);
        donebtn= v.findViewById(R.id.order_done);
        vieworder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,CompleteOrderList.class);
                intent.putExtra("TableNo",table_No.get(position).toString());
                intent.putExtra("OrderString",order.get(position));
                context.startActivity(intent);
            }
        });
        return v;
    }
}
